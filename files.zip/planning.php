<?php
// ─────────────────────────────────────────────────────────────
//  Base de données SQLite — créée automatiquement au 1er lancement
// ─────────────────────────────────────────────────────────────
$db = new SQLite3(__DIR__ . '/planning.db');
$db->exec("CREATE TABLE IF NOT EXISTS availabilities (
    name TEXT PRIMARY KEY,
    dates TEXT NOT NULL DEFAULT ''
)");

// ─────────────────────────────────────────────────────────────
//  API JSON (appelée en AJAX par le front)
// ─────────────────────────────────────────────────────────────
if (isset($_GET['api'])) {
    header('Content-Type: application/json');

    // GET /planning.php?api=get  → retourne toutes les dispos
    if ($_GET['api'] === 'get') {
        $result = $db->query("SELECT name, dates FROM availabilities");
        $data = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $data[$row['name']] = json_decode($row['dates'], true) ?? [];
        }
        echo json_encode($data);
        exit;
    }

    // POST /planning.php?api=save  → sauvegarde les dispos d'une personne
    if ($_GET['api'] === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $body = json_decode(file_get_contents('php://input'), true);
        $name  = trim($body['name'] ?? '');
        $dates = $body['dates'] ?? [];

        // Validation : le nom doit être dans la liste autorisée
        $allowed = [
            "Isabel Ramos","Alexandra","Flora","Tomas","Isabel Saraiva",
            "Gabrielle","Rui","Natea","Diane","Adriana",
            "Gabriel","Edgar","Carine","David Moniz","Carlos Almeida",
            "Marraine","Toto","Carl","Tiago",
            "costa ferreira joaquim","Rosa","Alexis","David"
        ];
        if (!in_array($name, $allowed)) {
            http_response_code(400);
            echo json_encode(['error' => 'Nom non autorisé']);
            exit;
        }

        $stmt = $db->prepare("INSERT INTO availabilities (name, dates)
                              VALUES (:name, :dates)
                              ON CONFLICT(name) DO UPDATE SET dates = :dates");
        $stmt->bindValue(':name',  $name);
        $stmt->bindValue(':dates', json_encode(array_values(array_filter($dates, 'is_int'))));
        $stmt->execute();
        echo json_encode(['ok' => true]);
        exit;
    }

    http_response_code(404);
    echo json_encode(['error' => 'Route inconnue']);
    exit;
}
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Les Dimanches — Mai · Juin 2025</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,700;1,400&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --gold:#f0b429;--gold-dim:rgba(240,180,41,.12);--gold-border:rgba(240,180,41,.25);
  --green:#96dc96;--green-dim:rgba(150,220,150,.1);--green-border:rgba(150,220,150,.25);
  --blue:#88aaff;--blue-dim:rgba(100,160,255,.1);--blue-border:rgba(100,160,255,.25);
  --text:#e8dcc8;--muted:#a09080;--faint:#605850;
}
body{
  min-height:100vh;
  background:linear-gradient(135deg,#0f0c1a 0%,#1a1030 50%,#0d1f2d 100%);
  font-family:'EB Garamond',Georgia,serif;color:var(--text);overflow-x:hidden;
}
body::before{
  content:'';position:fixed;inset:0;pointer-events:none;z-index:0;
  background:
    radial-gradient(ellipse at 20% 20%,rgba(255,180,50,.07) 0%,transparent 60%),
    radial-gradient(ellipse at 80% 80%,rgba(100,180,255,.05) 0%,transparent 60%);
}
.wrap{position:relative;z-index:1;max-width:900px;margin:0 auto;padding:0 16px}

/* HEADER */
header{text-align:center;padding:48px 0 32px}
.eyebrow{font-size:12px;letter-spacing:6px;text-transform:uppercase;color:var(--gold);margin-bottom:12px;opacity:.8}
h1{
  font-size:clamp(2rem,6vw,3.5rem);font-weight:400;letter-spacing:2px;
  background:linear-gradient(135deg,#fff8e7 30%,#f0b429);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;line-height:1.1;
}
h1 small{font-size:.55em;letter-spacing:4px;opacity:.8;display:block;margin-top:6px}
.badges{margin-top:20px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap}
.badge{border-radius:20px;padding:4px 14px;font-size:12px;border:1px solid;line-height:1.6}
.badge-gold{background:var(--gold-dim);border-color:var(--gold-border);color:var(--gold)}
.badge-green{background:var(--green-dim);border-color:var(--green-border);color:var(--green)}
.badge-blue{background:var(--blue-dim);border-color:var(--blue-border);color:var(--blue)}

/* VIEWS */
.view{display:none;padding-bottom:60px}.view.active{display:block}

/* HOME */
.home-btns{display:flex;gap:16px;justify-content:center;flex-wrap:wrap;padding:16px 0 60px}
.home-btn{
  display:flex;flex-direction:column;align-items:center;gap:10px;
  padding:32px 40px;border-radius:16px;cursor:pointer;
  font-family:'EB Garamond',Georgia,serif;font-size:16px;
  letter-spacing:.5px;min-width:180px;transition:all .2s;border:1.5px solid;
}
.home-btn .icon{font-size:22px}
.home-btn-gold{background:rgba(240,180,41,.1);border-color:rgba(240,180,41,.35);color:var(--gold)}
.home-btn-blue{background:rgba(100,160,255,.08);border-color:rgba(100,160,255,.25);color:var(--blue)}
.home-btn:hover{opacity:.8;transform:translateY(-1px)}

/* TOPBAR */
.topbar{display:flex;align-items:center;gap:12px;margin-bottom:32px;flex-wrap:wrap}
.topbar-label{font-size:11px;color:var(--muted);letter-spacing:2px;text-transform:uppercase}
.spacer{flex:1}

/* BUTTONS */
.btn-back,.btn-small{
  padding:8px 16px;background:rgba(255,255,255,.05);
  border:1px solid rgba(255,255,255,.1);border-radius:8px;
  color:var(--muted);cursor:pointer;font-size:13px;
  font-family:'EB Garamond',Georgia,serif;transition:all .15s;
}
.btn-back:hover,.btn-small:hover{background:rgba(255,255,255,.09)}
.btn-submit{
  padding:12px 28px;background:linear-gradient(135deg,#f0b429,#e07b00);
  border:none;border-radius:10px;color:#1a0a00;font-weight:700;font-size:15px;
  cursor:pointer;font-family:'EB Garamond',Georgia,serif;transition:opacity .2s;
}
.btn-submit:hover{opacity:.85}
.btn-submit:disabled{opacity:.5;cursor:not-allowed}
.btn-modify{
  padding:8px 18px;background:rgba(240,180,41,.15);
  border:1px solid rgba(240,180,41,.35);border-radius:8px;
  color:var(--gold);cursor:pointer;font-size:13px;
  font-family:'EB Garamond',Georgia,serif;transition:all .15s;
}
.btn-modify:hover{background:rgba(240,180,41,.22)}

/* FORM */
.form-title{font-size:1.5rem;font-weight:400;margin-bottom:8px;color:#fff8e7}
.form-sub{color:var(--muted);font-size:14px;margin:0 0 28px}
.dept-label{font-size:11px;letter-spacing:3px;text-transform:uppercase;margin-bottom:12px;display:flex;align-items:center;gap:8px}
.dot{width:8px;height:8px;border-radius:50%;display:inline-block}
.name-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:8px;margin-bottom:28px}
.name-btn{
  padding:12px 14px;border-radius:10px;cursor:pointer;font-size:13px;
  text-align:left;position:relative;transition:all .15s;
  font-family:'EB Garamond',Georgia,serif;
  border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);color:#d0c4b0;
}
.name-btn.g{background:rgba(150,220,150,.15);border-color:rgba(150,220,150,.4);color:var(--green)}
.name-btn.b{background:rgba(100,160,255,.15);border-color:rgba(100,160,255,.4);color:var(--blue)}
.name-btn .tick{position:absolute;top:7px;right:9px;font-size:10px}
.name-btn:hover{opacity:.8;transform:translateY(-1px)}
.greeting{display:flex;align-items:center;gap:10px;margin-bottom:4px}
.greeting h2{font-size:1.5rem;font-weight:400;color:#fff8e7}
.dept-tag{font-size:11px;padding:2px 10px;border-radius:10px;border:1px solid}
.dept-tag-91{background:rgba(150,220,150,.15);color:var(--green);border-color:rgba(150,220,150,.3)}
.dept-tag-93{background:rgba(100,160,255,.15);color:var(--blue);border-color:rgba(100,160,255,.3)}
.date-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin:28px 0 32px}
.date-btn{
  padding:16px 12px;border-radius:12px;cursor:pointer;font-size:13px;transition:all .15s;
  display:flex;flex-direction:column;align-items:center;gap:4px;
  border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);
  color:var(--muted);font-family:'EB Garamond',Georgia,serif;
}
.date-btn .emo{font-size:20px}
.date-btn.checked{background:rgba(240,180,41,.18);border:1.5px solid var(--gold);color:#fff8e7;font-weight:600}
.form-actions{display:flex;gap:12px;flex-wrap:wrap;align-items:center}
.toast{
  margin-top:20px;padding:14px 20px;
  background:rgba(100,220,100,.15);border:1px solid rgba(100,220,100,.3);
  border-radius:10px;color:#80e880;font-size:14px;text-align:center;display:none;
}
.toast.show{display:block}
.toast.error{background:rgba(220,80,80,.15);border-color:rgba(220,80,80,.3);color:#ff9999}

/* PLANNING */
.legend{display:flex;gap:16px;margin-bottom:24px;flex-wrap:wrap}
.legend-item{font-size:12px;display:flex;align-items:center;gap:6px}
.dot-sm{width:10px;height:10px;border-radius:50%;display:inline-block}
.week-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:16px;overflow:hidden;margin-bottom:20px}
.week-header{
  padding:14px 20px;background:rgba(240,180,41,.08);
  border-bottom:1px solid rgba(240,180,41,.15);
  display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;
}
.week-date-label{font-size:11px;color:var(--gold);letter-spacing:3px;text-transform:uppercase}
.week-date-val{font-size:18px;font-weight:500;color:#fff8e7}
.week-badges{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.week-badge{border-radius:12px;padding:3px 10px;font-size:12px;border:1px solid}
.wbg{background:rgba(150,220,150,.12);border-color:rgba(150,220,150,.25);color:var(--green)}
.wbb{background:rgba(100,160,255,.1);border-color:rgba(100,160,255,.2);color:var(--blue)}
.wbo{background:rgba(240,180,41,.1);border-color:rgba(240,180,41,.2);color:var(--gold)}
.week-body{padding:16px 20px}
.groups-row{display:flex;gap:12px;flex-wrap:wrap}
.group-card{border-radius:12px;padding:12px 16px;min-width:140px;flex:1 1 140px;max-width:220px;border:1px solid}
.gc-green{background:rgba(150,220,150,.08);border-color:rgba(150,220,150,.28)}
.gc-blue{background:rgba(100,160,255,.08);border-color:rgba(100,160,255,.28)}
.group-hdr{font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center}
.group-tag{border-radius:6px;padding:1px 8px;font-size:10px}
.gt-green{background:rgba(150,220,150,.18);color:var(--green)}
.gt-blue{background:rgba(100,160,255,.18);color:var(--blue)}
.member{font-size:13px;color:#e0d4c0;display:flex;align-items:center;gap:6px;margin-bottom:5px}
.dot-xs{width:6px;height:6px;border-radius:50%;flex-shrink:0;display:inline-block}
.no-dispo{color:var(--faint);font-size:13px;font-style:italic}
.absent-section{margin-top:14px}
.absent-label{font-size:11px;color:var(--faint);letter-spacing:1px;text-transform:uppercase;margin-bottom:6px}
.absent-tags{display:flex;flex-wrap:wrap;gap:6px}
.absent-tag{font-size:11px;color:var(--faint);background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:6px;padding:3px 8px}
.empty-state{text-align:center;padding:60px 20px;color:var(--muted);font-size:15px}
.empty-state a{color:var(--gold);cursor:pointer;text-decoration:underline}

/* LOADING */
#loading{position:fixed;inset:0;background:#0f0c1a;display:flex;align-items:center;justify-content:center;z-index:100;transition:opacity .4s}
#loading.hide{opacity:0;pointer-events:none}
.spinner{width:32px;height:32px;border:2px solid rgba(240,180,41,.2);border-top-color:var(--gold);border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.sync-dot{width:7px;height:7px;border-radius:50%;background:var(--green);display:inline-block;margin-right:6px;animation:pulse 2s ease-in-out infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}

@media(max-width:500px){
  .home-btn{padding:24px 28px;min-width:140px}
  .date-grid{grid-template-columns:repeat(auto-fill,minmax(110px,1fr))}
}
</style>
</head>
<body>

<div id="loading"><div class="spinner"></div></div>

<div class="wrap">
  <header>
    <div class="eyebrow">Planification des dimanches</div>
    <h1>Les Dimanches<small>Mai · Juin 2025</small></h1>
    <div class="badges">
      <span class="badge badge-gold" id="badge-resp">0 / 23 réponses</span>
      <span class="badge badge-green">🟢 91 &middot; 15 personnes</span>
      <span class="badge badge-blue">🔵 93 &middot; 8 personnes</span>
    </div>
  </header>

  <!-- HOME -->
  <div id="view-home" class="view active">
    <div class="home-btns">
      <button class="home-btn home-btn-gold" onclick="showView('form');resetForm()">
        <span class="icon">📅</span><span>Mes disponibilités</span>
      </button>
      <button class="home-btn home-btn-blue" onclick="showView('planning')">
        <span class="icon">👁️</span><span>Voir le planning</span>
      </button>
    </div>
  </div>

  <!-- FORM -->
  <div id="view-form" class="view">
    <div class="topbar">
      <button class="btn-back" onclick="showView('home')">← Retour</button>
      <span class="topbar-label">Disponibilités</span>
    </div>

    <div id="step1">
      <h2 class="form-title">Qui es-tu ?</h2>
      <p class="form-sub">Sélectionne ton prénom dans la liste.</p>
      <div class="dept-label" style="color:var(--green)">
        <span class="dot" style="background:var(--green)"></span>Département 91
      </div>
      <div class="name-grid" id="names-91"></div>
      <div class="dept-label" style="color:var(--blue)">
        <span class="dot" style="background:var(--blue)"></span>Département 93
      </div>
      <div class="name-grid" id="names-93"></div>
    </div>

    <div id="step2" style="display:none">
      <div class="greeting">
        <h2 id="greeting-name"></h2>
        <span class="dept-tag" id="greeting-dept"></span>
      </div>
      <p class="form-sub" style="margin-top:4px">Coche les dimanches où tu es disponible.</p>
      <div class="date-grid" id="date-grid"></div>
      <div class="form-actions">
        <button class="btn-small" onclick="selectAll()">Tout sélectionner</button>
        <button class="btn-small" onclick="selectNone()">Tout décocher</button>
        <div class="spacer"></div>
        <button class="btn-small" onclick="goStep1()">← Changer de nom</button>
        <button class="btn-submit" id="btn-save" onclick="submitAvail()">Valider ✓</button>
      </div>
      <div class="toast" id="toast"></div>
    </div>
  </div>

  <!-- PLANNING -->
  <div id="view-planning" class="view">
    <div class="topbar">
      <button class="btn-back" onclick="showView('home')">← Retour</button>
      <span class="topbar-label">Planning des groupes</span>
      <div class="spacer"></div>
      <span style="font-size:12px;color:var(--muted)">
        <span class="sync-dot"></span>Mise à jour auto
      </span>
      <button class="btn-modify" onclick="showView('form');resetForm()">📅 Modifier mes dispo</button>
    </div>
    <div class="legend">
      <span class="legend-item" style="color:var(--green)">
        <span class="dot-sm" style="background:var(--green)"></span>Groupes du 91
      </span>
      <span class="legend-item" style="color:var(--blue)">
        <span class="dot-sm" style="background:var(--blue)"></span>Groupes du 93
      </span>
    </div>
    <div id="planning-body"></div>
  </div>
</div>

<script>
// ── DONNÉES ───────────────────────────────────────────────────
const DEPT_91 = [
  "Isabel Ramos","Alexandra","Flora","Tomas","Isabel Saraiva",
  "Gabrielle","Rui","Natea","Diane","Adriana",
  "Gabriel","Edgar","Carine","David Moniz","Carlos Almeida"
];
const DEPT_93 = [
  "Marraine","Toto","Carl","Tiago",
  "costa ferreira joaquim","Rosa","Alexis","David"
];
const NAMES = [...DEPT_91,...DEPT_93];
const SUNDAYS = [
  new Date(2025,4,10),new Date(2025,4,17),new Date(2025,4,24),new Date(2025,4,31),
  new Date(2025,5,7),new Date(2025,5,14),new Date(2025,5,21),new Date(2025,5,28),
];
const fmt = d => d.toLocaleDateString("fr-FR",{day:"numeric",month:"long"});
const fmtS = d => d.toLocaleDateString("fr-FR",{day:"numeric",month:"short"});
const dept = n => DEPT_91.includes(n) ? "91" : "93";

// ── STATE ─────────────────────────────────────────────────────
let avail = {};
let selName = "";
let tmpAvail = [];
let pollTimer = null;

// ── API ───────────────────────────────────────────────────────
async function apiGet() {
  const r = await fetch('?api=get');
  avail = await r.json();
  updateBadge();
}

async function apiSave(name, dates) {
  const r = await fetch('?api=save', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({name, dates})
  });
  return r.json();
}

// ── VUES ──────────────────────────────────────────────────────
function showView(v) {
  document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
  document.getElementById('view-'+v).classList.add('active');
  if (v === 'planning') { renderPlanning(); startPoll(); }
  else stopPoll();
}

// Polling toutes les 5s sur la vue planning
function startPoll() {
  stopPoll();
  pollTimer = setInterval(async () => {
    await apiGet();
    renderPlanning();
  }, 5000);
}
function stopPoll() { clearInterval(pollTimer); }

// ── FORMULAIRE ────────────────────────────────────────────────
function resetForm() {
  selName = ""; tmpAvail = [];
  document.getElementById('step1').style.display = 'block';
  document.getElementById('step2').style.display = 'none';
  renderNameGrids();
}
function goStep1() {
  document.getElementById('step1').style.display = 'block';
  document.getElementById('step2').style.display = 'none';
}

function renderNameGrids() {
  renderGrid('names-91', DEPT_91, 'g');
  renderGrid('names-93', DEPT_93, 'b');
}
function renderGrid(id, names, cls) {
  const el = document.getElementById(id);
  el.innerHTML = '';
  names.forEach(n => {
    const has = !!avail[n];
    const btn = document.createElement('button');
    btn.className = 'name-btn' + (has ? ' '+cls : '');
    btn.textContent = n;
    if (has) { const t = document.createElement('span'); t.className='tick'; t.textContent='✓'; btn.appendChild(t); }
    btn.onclick = () => selectName(n);
    el.appendChild(btn);
  });
}

function selectName(n) {
  selName = n; tmpAvail = avail[n] ? [...avail[n]] : [];
  document.getElementById('step1').style.display = 'none';
  document.getElementById('step2').style.display = 'block';
  const d = dept(n);
  document.getElementById('greeting-name').innerHTML =
    `Bonjour, <span style="color:${d==='91'?'var(--green)':'var(--blue)'}">${n}</span> 👋`;
  const dt = document.getElementById('greeting-dept');
  dt.className = `dept-tag dept-tag-${d}`; dt.textContent = d;
  renderDateGrid();
}

function renderDateGrid() {
  const grid = document.getElementById('date-grid');
  grid.innerHTML = '';
  SUNDAYS.forEach((d,i) => {
    const ok = tmpAvail.includes(i);
    const btn = document.createElement('button');
    btn.className = 'date-btn'+(ok?' checked':'');
    btn.id = 'db-'+i;
    btn.innerHTML = `<span class="emo">${ok?'✅':'⬜'}</span><span>${fmtS(d)}</span>`;
    btn.onclick = () => toggleDate(i);
    grid.appendChild(btn);
  });
}
function toggleDate(i) {
  tmpAvail = tmpAvail.includes(i) ? tmpAvail.filter(x=>x!==i) : [...tmpAvail,i];
  const btn = document.getElementById('db-'+i);
  const ok = tmpAvail.includes(i);
  btn.className = 'date-btn'+(ok?' checked':'');
  btn.innerHTML = `<span class="emo">${ok?'✅':'⬜'}</span><span>${fmtS(SUNDAYS[i])}</span>`;
}
function selectAll()  { tmpAvail = SUNDAYS.map((_,i)=>i); renderDateGrid(); }
function selectNone() { tmpAvail = []; renderDateGrid(); }

async function submitAvail() {
  const btn = document.getElementById('btn-save');
  btn.disabled = true; btn.textContent = 'Enregistrement…';
  const res = await apiSave(selName, tmpAvail);
  const toast = document.getElementById('toast');
  if (res.ok) {
    avail[selName] = [...tmpAvail];
    updateBadge();
    toast.className = 'toast show';
    toast.textContent = '✅ Disponibilités enregistrées ! Redirection vers le planning…';
    setTimeout(() => { toast.className='toast'; showView('planning'); }, 1500);
  } else {
    toast.className = 'toast error show';
    toast.textContent = '❌ Erreur : ' + (res.error || 'Réessaie.');
  }
  btn.disabled = false; btn.textContent = 'Valider ✓';
}

// ── GROUPES ───────────────────────────────────────────────────
function buildDeptGroups(people, prev) {
  if (!people.length) return [];
  const done = new Set(); const groups = [];
  if (prev) prev.forEach(pg => {
    const k = pg.filter(n => people.includes(n));
    if (k.length) { groups.push(k); k.forEach(n => done.add(n)); }
  });
  people.filter(n => !done.has(n)).forEach(n => {
    const t = groups.find(g => g.length < 5);
    if (t) t.push(n); else groups.push([n]);
  });
  const merged = []; let over = [];
  groups.forEach(g => {
    if (g.length >= 4) { if (over.length) g.push(...over.splice(0, 5-g.length)); merged.push(g); }
    else over.push(...g);
  });
  over.forEach(n => {
    const t = merged.find(g => g.length < 5);
    if (t) t.push(n);
    else if (!merged.length || merged[merged.length-1].length >= 4) merged.push([n]);
    else merged[merged.length-1].push(n);
  });
  return merged.filter(g => g.length);
}
function buildGroups(names, prev) {
  if (!names.length) return [];
  const a91 = names.filter(n => DEPT_91.includes(n));
  const a93 = names.filter(n => DEPT_93.includes(n));
  const p91 = prev ? prev.filter(g => g.every(n => DEPT_91.includes(n))) : null;
  const p93 = prev ? prev.filter(g => g.every(n => DEPT_93.includes(n))) : null;
  return [...buildDeptGroups(a91,p91),...buildDeptGroups(a93,p93)];
}

// ── PLANNING ──────────────────────────────────────────────────
function renderPlanning() {
  const body = document.getElementById('planning-body');
  if (!Object.keys(avail).length) {
    body.innerHTML = `<div class="empty-state">Personne n'a encore renseigné ses disponibilités.<br>
      <a onclick="showView('form');resetForm()">Sois le premier ! →</a></div>`;
    return;
  }
  let prev = null; let html = '';
  SUNDAYS.forEach((d,i) => {
    const names = NAMES.filter(n => avail[n] && avail[n].includes(i));
    const groups = buildGroups(names, prev); prev = groups;
    const c91 = names.filter(n=>DEPT_91.includes(n)).length;
    const c93 = names.filter(n=>DEPT_93.includes(n)).length;
    html += `<div class="week-card">
      <div class="week-header">
        <div>
          <div class="week-date-label">Dimanche</div>
          <div class="week-date-val">${fmt(d)}</div>
        </div>
        <div class="week-badges">
          <span class="week-badge wbg">🟢 ${c91}/${DEPT_91.length}</span>
          <span class="week-badge wbb">🔵 ${c93}/${DEPT_93.length}</span>
          <span class="week-badge wbo">${groups.length} groupe${groups.length>1?'s':''}</span>
        </div>
      </div>
      <div class="week-body">`;
    if (!groups.length) {
      html += `<div class="no-dispo">Personne de disponible ce jour-là.</div>`;
    } else {
      html += `<div class="groups-row">`;
      groups.forEach((g,gi) => {
        const is91 = g.every(n=>DEPT_91.includes(n));
        const cc = is91 ? 'green' : 'blue';
        html += `<div class="group-card gc-${cc}">
          <div class="group-hdr" style="color:var(--${cc})">
            <span>Groupe ${gi+1}</span>
            <span class="group-tag gt-${cc}">${is91?'91':'93'}</span>
          </div>`;
        g.forEach(n => {
          const dc = DEPT_91.includes(n)?'green':'blue';
          html += `<div class="member"><span class="dot-xs" style="background:var(--${dc})"></span>${n}</div>`;
        });
        html += `</div>`;
      });
      html += `</div>`;
    }
    const absent = NAMES.filter(n => !names.includes(n));
    if (absent.length) {
      html += `<div class="absent-section"><div class="absent-label">Pas encore répondu ou indisponible</div>
        <div class="absent-tags">`;
      absent.forEach(n => {
        html += `<span class="absent-tag">${avail[n]?'✗ ':'? '}${n}</span>`;
      });
      html += `</div></div>`;
    }
    html += `</div></div>`;
  });
  body.innerHTML = html;
}

// ── BADGE ─────────────────────────────────────────────────────
function updateBadge() {
  document.getElementById('badge-resp').textContent =
    `${Object.keys(avail).length} / ${NAMES.length} réponses`;
}

// ── INIT ──────────────────────────────────────────────────────
(async () => {
  await apiGet();
  renderNameGrids();
  document.getElementById('loading').classList.add('hide');
  setTimeout(() => document.getElementById('loading').style.display='none', 400);
})();
</script>
</body>
</html>
